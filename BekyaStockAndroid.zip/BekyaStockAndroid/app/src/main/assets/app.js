const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const KEY='bekya_stock_v1';
const initial={devices:[],outputs:[],transfers:[],sales:[],role:'admin',warehouses:['مخزن الإسكندرية الرئيسي','مخزن البحيرة','مخزن القاهرة']};
let db=JSON.parse(localStorage.getItem(KEY)||'null')||initial;
const save=()=>{localStorage.setItem(KEY,JSON.stringify(db));render()};
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const unit=u=>({kg:'كيلو',piece:'قطعة',ton:'طن'}[u]||u);
const id=prefix=>prefix+'-'+Date.now().toString().slice(-8);
const dateNow=()=>new Date().toISOString().slice(0,10);
function options(){return db.warehouses.map(w=>`<option>${esc(w)}</option>`).join('')}
function fillWarehouses(){$$('.warehouse-options').forEach(s=>{const old=s.value;s.innerHTML=options();if(db.warehouses.includes(old))s.value=old})}
function table(headers,rows){if(!rows.length)return '<div class="empty">لا توجد بيانات مسجلة حتى الآن</div>';return `<table><thead><tr>${headers.map(h=>`<th>${h}</th>`).join('')}</tr></thead><tbody>${rows.join('')}</tbody></table>`}
function render(){
 fillWarehouses();
 $('#deviceCount').textContent=db.devices.length;$('#materialCount').textContent=new Set(db.outputs.map(x=>x.material.toLowerCase())).size;
 $('#pendingCount').textContent=db.transfers.filter(x=>x.status==='بانتظار الموافقة').length;$('#invoiceCount').textContent=db.sales.length;
 $('#devicesTable').innerHTML=table(['الباركود','اسم الجهاز','المخزن','الوزن (كجم)','تاريخ الاستلام'],db.devices.map(x=>`<tr><td>${esc(x.barcode)}</td><td>${esc(x.name)}</td><td>${esc(x.warehouse)}</td><td>${x.weight||0}</td><td>${esc(x.date)}</td></tr>`));
 $('#outputsTable').innerHTML=table(['الجهاز','الصنف','الكمية','الوحدة','المخزن','التاريخ'],db.outputs.map(x=>`<tr><td>${esc(x.barcode)}</td><td>${esc(x.material)}</td><td>${x.quantity}</td><td>${unit(x.unit)}</td><td>${esc(x.warehouse)}</td><td>${esc(x.date)}</td></tr>`));
 const balances={};db.outputs.forEach(x=>{const k=[x.material,x.warehouse,x.unit].join('|');balances[k]=(balances[k]||0)+Number(x.quantity)});db.sales.forEach(x=>{const k=[x.material,x.warehouse,x.unit].join('|');balances[k]=(balances[k]||0)-Number(x.quantity)});
 $('#inventoryTable').innerHTML=table(['الصنف','المخزن','الرصيد','الوحدة'],Object.entries(balances).map(([k,v])=>{const [m,w,u]=k.split('|');return `<tr><td>${esc(m)}</td><td>${esc(w)}</td><td>${v.toFixed(3)}</td><td>${unit(u)}</td></tr>`}));
 $('#transfersTable').innerHTML=table(['رقم الطلب','الصنف','الكمية','من','إلى','الحالة','إجراء'],db.transfers.map(x=>`<tr><td>${x.id}</td><td>${esc(x.material)}</td><td>${x.quantity} ${unit(x.unit)}</td><td>${esc(x.from)}</td><td>${esc(x.to)}</td><td><span class="tag">${x.status}</span></td><td>${x.status==='بانتظار الموافقة'&&db.role==='admin'?`<button class="action" onclick="approveTransfer('${x.id}')">موافقة</button>`:'—'}</td></tr>`));
 $('#salesTable').innerHTML=table(['رقم الفاتورة','العميل','الصنف','الكمية','سعر الوحدة','الإجمالي','التاريخ'],db.sales.map(x=>`<tr><td>${x.id}</td><td>${esc(x.customer)}</td><td>${esc(x.material)}</td><td>${x.quantity} ${unit(x.unit)}</td><td>${x.price.toFixed(2)}</td><td>${(x.quantity*x.price).toFixed(2)}</td><td>${x.date}</td></tr>`));
 const recent=[...db.outputs.map(x=>({label:`إضافة ${x.quantity} ${unit(x.unit)} من ${x.material}`,date:x.date})),...db.sales.map(x=>({label:`فاتورة بيع للعميل ${x.customer}`,date:x.date}))].slice(-6).reverse();
 $('#recentMovements').innerHTML=table(['الحركة','التاريخ'],recent.map(x=>`<tr><td>${esc(x.label)}</td><td>${x.date}</td></tr>`));
 $('#roleSelect').value=db.role;$('#roleHint').textContent=db.role==='admin'?'عرض جميع المخازن':'وضع أمين مخزن (تجريبي)';
}
function formData(form){return Object.fromEntries(new FormData(form).entries())}
$('#deviceForm').addEventListener('submit',e=>{e.preventDefault();const x=formData(e.target);if(db.devices.some(d=>d.barcode===x.barcode))return alert('هذا الباركود مسجل بالفعل');db.devices.push({...x,weight:Number(x.weight||0)});e.target.reset();save();alert('تم تسجيل الجهاز')});
$('#outputForm').addEventListener('submit',e=>{e.preventDefault();const x=formData(e.target);if(!db.devices.some(d=>d.barcode===x.barcode))return alert('لم يتم العثور على جهاز بهذا الباركود');db.outputs.push({...x,quantity:Number(x.quantity),date:dateNow(),id:id('OUT')});e.target.reset();save();alert('تم تسجيل ناتج التفكيك')});
$('#transferForm').addEventListener('submit',e=>{e.preventDefault();const x=formData(e.target);if(x.from===x.to)return alert('اختر مخزنين مختلفين');db.transfers.push({...x,quantity:Number(x.quantity),id:id('TR'),status:'بانتظار الموافقة',date:dateNow()});e.target.reset();save();alert('تم إرسال طلب التحويل للمدير')});
window.approveTransfer=transferId=>{const t=db.transfers.find(x=>x.id===transferId);if(t){t.status='تمت الموافقة';save()}};
$('#saleForm').addEventListener('submit',e=>{e.preventDefault();const x=formData(e.target);const available=stockFor(x.material,x.warehouse,x.unit);if(available<Number(x.quantity))return alert(`الرصيد غير كافٍ. الرصيد الحالي: ${available}`);db.sales.push({...x,quantity:Number(x.quantity),price:Number(x.price),id:id('INV'),date:dateNow()});e.target.reset();save();alert('تم تسجيل الفاتورة المبدئية')});
function stockFor(m,w,u){let n=0;db.outputs.filter(x=>x.material.toLowerCase()===m.toLowerCase()&&x.warehouse===w&&x.unit===u).forEach(x=>n+=Number(x.quantity));db.sales.filter(x=>x.material.toLowerCase()===m.toLowerCase()&&x.warehouse===w&&x.unit===u).forEach(x=>n-=Number(x.quantity));return n}
$$('.nav').forEach(b=>b.addEventListener('click',()=>{$$('.nav').forEach(n=>n.classList.remove('active'));b.classList.add('active');$$('.page').forEach(p=>p.classList.remove('active'));$('#'+b.dataset.page).classList.add('active')}));
$('#roleSelect').addEventListener('change',e=>{db.role=e.target.value;save()});
$('#today').textContent=new Date().toLocaleDateString('ar-EG',{year:'numeric',month:'long',day:'numeric'});
$('#backupBtn').addEventListener('click',()=>{const blob=new Blob([JSON.stringify(db,null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='bekya-stock-backup.json';a.click();URL.revokeObjectURL(a.href)});
if('serviceWorker' in navigator)window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));
if(!localStorage.getItem(KEY)){db.outputs=[{id:'OUT-DEMO',barcode:'DEV-DEMO-01',material:'حديد',quantity:25,unit:'kg',warehouse:db.warehouses[0],date:dateNow()},{id:'OUT-DEMO-02',barcode:'DEV-DEMO-01',material:'موتور',quantity:2,unit:'piece',warehouse:db.warehouses[0],date:dateNow()}];db.devices=[{barcode:'DEV-DEMO-01',name:'جهاز تجريبي',warehouse:db.warehouses[0],weight:35,date:dateNow()}];save()}else render();
